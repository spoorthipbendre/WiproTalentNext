package String;

public class LowerCaseConversion {	
	public static void main(String args[]) {
		String str = "Java Coding";
		String lowercase = str.toLowerCase();
		String uppercase = str.toUpperCase();
		System.out.println("Original String:"+str);
		System.out.println("String in LowerCase:"+lowercase);
		System.out.println("String in UpperCase:"+uppercase);
		
	}
}
