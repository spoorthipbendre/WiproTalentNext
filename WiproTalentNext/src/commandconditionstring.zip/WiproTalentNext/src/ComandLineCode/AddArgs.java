
package ComandLineCode;

public class AddArgs {
	public static void main(String args[]) {
		String a = args[0];
		String b = args[1];
		System.out.println(a+" Technologies "+b);
		
	}

}
